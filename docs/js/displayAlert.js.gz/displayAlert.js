﻿export function displayAlert(message) {
    alert(message);
}